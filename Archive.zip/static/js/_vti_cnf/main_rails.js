vti_encoding:SR|utf8-nl
vti_author:SR|Connor-HP\\Connor
vti_modifiedby:SR|Connor-HP\\Connor
vti_timelastmodified:TR|16 Nov 2014 00:59:08 -0000
vti_timecreated:TR|16 Nov 2014 00:58:39 -0000
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|index.html
vti_nexttolasttimemodified:TW|16 Nov 2014 00:58:50 -0000
vti_cacheddtm:TX|16 Nov 2014 00:59:08 -0000
vti_filesize:IR|3207
